const { body,validationResult } = require('express-validator/check');
const { sanitizeBody } = require('express-validator/filter');
var TerminologyInstance = require('../models/terminologyinstance');
var Terminology = require('../models/terminology');

/// Display list of all BookInstances.
exports.terminologyinstance_list = function(req, res, next) {

    TerminologyInstance.find()
      .populate('terminology')
      .exec(function (err, list_terminologyinstances) {
        if (err) { return next(err); }
        // Successful, so render
        res.render('terminologyinstance_list', { title: 'Terminology Instance List', terminologyinstance_list: list_terminologyinstances });
      });
      
  };

// Display detail page for a specific BookInstance.
exports.terminologyinstance_detail = function(req, res, next) {

    TerminologyInstance.findById(req.params.id)
    .populate('terminology')
    .exec(function (err, terminologyinstance) {
      if (err) { return next(err); }
      if (terminologyinstance==null) { // No results.
          var err = new Error('Terminology copy not found');
          err.status = 404;
          return next(err);
        }
      // Successful, so render.
      res.render('terminologyinstance_detail', { title: 'Terminology:', terminologyinstance:  terminologyinstance});
    })

};

// Display BookInstance create form on GET.
exports.terminologyinstance_create_get = function(req, res, next) {       

    Terminology.find({},'title')
    .exec(function (err, terminologies) {
      if (err) { return next(err); }
      // Successful, so render.
      res.render('terminologyinstance_form', {title: 'Create TerminologyInstance', terminology_list: terminologies});
    });
    
};

// Handle BookInstance create on POST.
exports.terminologyinstance_create_post = [

    // Validate fields.
    body('terminology', 'Terminology must be specified').isLength({ min: 1 }).trim(),
    //body('imprint', 'Imprint must be specified').isLength({ min: 1 }).trim(),
    //body('due_back', 'Invalid date').optional({ checkFalsy: true }).isISO8601(),
    
    // Sanitize fields.
    sanitizeBody('terminology').escape(),
    //sanitizeBody('imprint').escape(),
    sanitizeBody('status').trim().escape(),
    //sanitizeBody('due_back').toDate(),
    
    // Process request after validation and sanitization.
    (req, res, next) => {

        // Extract the validation errors from a request.
        const errors = validationResult(req);

        // Create a BookInstance object with escaped and trimmed data.
        var terminologyinstance = new TerminologyInstance(
          { terminology: req.body.terminology,
            //imprint: req.body.imprint,
            status: req.body.status,
            //due_back: req.body.due_back
           });

        if (!errors.isEmpty()) {
            // There are errors. Render form again with sanitized values and error messages.
            Terminology.find({},'title')
                .exec(function (err, terminologies) {
                    if (err) { return next(err); }
                    // Successful, so render.
                    res.render('terminologyinstance_form', { title: 'Create TerminologyInstance', terminology_list: terminologies, selected_terminology: terminologyinstance.terminology._id , errors: errors.array(), terminologyinstance: terminologyinstance });
            });
            return;
        }
        else {
            // Data from form is valid.
            terminologyinstance.save(function (err) {
                if (err) { return next(err); }
                   // Successful - redirect to new record.
                   res.redirect(terminologyinstance.url);
                });
        }
    }
];

// Display TerminologyInstance delete form on GET.
exports.terminologyinstance_delete_get = function(req, res) {
    res.send('NOT IMPLEMENTED: TerminologyInstance delete GET');
};

// Handle TerminologyInstance delete on POST.
exports.terminologyinstance_delete_post = function(req, res) {
    res.send('NOT IMPLEMENTED: TerminologyInstance delete POST');
};

// Display TerminologyInstance update form on GET.
exports.terminologyinstance_update_get = function(req, res) {
    res.send('NOT IMPLEMENTED: TerminologyInstance update GET');
};

// Handle TerminologyInstance update on POST.
exports.terminologyinstance_update_post = function(req, res) {
    res.send('NOT IMPLEMENTED: TerminologyInstance update POST');
};