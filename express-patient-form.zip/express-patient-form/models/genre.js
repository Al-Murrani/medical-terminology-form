var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var GenreSchema = new Schema(
  {
    category: {type: String, required: true, enum: ['disease', 'symptom', 'procedure', 'drug'], default: 'symptom'},
  }
);

// Virtual for type's URL
GenreSchema
.virtual('url')
.get(function () {
  return '/catalog/genre/' + this._id;
});

//Export model
module.exports = mongoose.model('Genre', GenreSchema);