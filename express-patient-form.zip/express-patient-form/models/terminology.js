var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var TerminologySchema = new Schema(
  {
    title: {type: String, required: true},
    author: {type: Schema.Types.ObjectId, ref: 'Author', required: true},
    summary: {type: String, required: true},
    code: {type: String, required: true},
    genre: [{type: Schema.Types.ObjectId, ref: 'Genre'}]
  }
);

// Virtual for terminology's URL
TerminologySchema
.virtual('url')
.get(function () {
  return '/catalog/terminology/' + this._id;
});

//Export model
module.exports = mongoose.model('Terminology', TerminologySchema);