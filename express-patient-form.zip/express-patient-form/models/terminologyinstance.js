var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var TerminologyInstanceSchema = new Schema(
  {
    terminology: { type: Schema.Types.ObjectId, ref: 'Terminology', required: true }, //reference to the associated terminology
    //imprint: {type: String, required: true},
    status: {type: String, required: true, enum: ['Ongoing', 'Review', 'Done', 'Approved'], default: 'Review'},
    //due_back: {type: Date, default: Date.now}
  }
);

// Virtual for terminologyinstance's URL
TerminologyInstanceSchema
.virtual('url')
.get(function () {
  return '/catalog/terminologyinstance/' + this._id;
});

//Export model
module.exports = mongoose.model('TerminologyInstance', TerminologyInstanceSchema);